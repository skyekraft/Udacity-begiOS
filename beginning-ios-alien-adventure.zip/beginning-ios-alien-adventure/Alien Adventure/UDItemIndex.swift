//
//  UDItemIndex.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 9/28/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

import Foundation

// MARK: - UDItemIndex

class UDItemIndex {
    
    // MARK: Properties
    
    static var items = [String:UDItem]()
}